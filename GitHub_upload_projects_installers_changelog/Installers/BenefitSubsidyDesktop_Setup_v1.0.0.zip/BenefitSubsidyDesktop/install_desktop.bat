@echo off
set TARGET=%ProgramFiles%\BenefitSubsidyDesktop
mkdir "%TARGET%"
xcopy /Y /E "%~dp0*" "%TARGET%\"
echo Installed to %TARGET%
pause
