BenefitSubsidyDesktop v1.0.0
1. Распаковать архив.
2. Запустить install_desktop.bat от имени администратора или BenefitSubsidyDesktop.exe напрямую.
3. Настроить Firebase URL, Web API Key, email и пароль в окне настроек.
